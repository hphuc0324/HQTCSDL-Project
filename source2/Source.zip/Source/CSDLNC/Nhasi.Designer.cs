﻿namespace CSDLNC
{
    partial class Nhasi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Nhasi));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.panel5 = new System.Windows.Forms.Panel();
            this.pComboGenBox = new System.Windows.Forms.ComboBox();
            this.pAddressBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.button11 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.pPhoneBox = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.pEmailBox = new System.Windows.Forms.TextBox();
            this.pDOBBox = new System.Windows.Forms.TextBox();
            this.pNameBox = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.panel6 = new System.Windows.Forms.Panel();
            this.button3 = new System.Windows.Forms.Button();
            this.label40 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.dID = new System.Windows.Forms.TextBox();
            this.dGender = new System.Windows.Forms.TextBox();
            this.dName = new System.Windows.Forms.TextBox();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.sIDBox = new System.Windows.Forms.TextBox();
            this.sGenderBox = new System.Windows.Forms.TextBox();
            this.sNameBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.currGenderBox = new System.Windows.Forms.ComboBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button10 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.currUserTypeBox = new System.Windows.Forms.TextBox();
            this.currPasswordBox = new System.Windows.Forms.TextBox();
            this.currNameBox = new System.Windows.Forms.TextBox();
            this.currUsernameBox = new System.Windows.Forms.TextBox();
            this.currIDBox = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.apStatusBox = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.apPatientBox = new System.Windows.Forms.TextBox();
            this.apDentistBox = new System.Windows.Forms.TextBox();
            this.apRoomBox = new System.Windows.Forms.TextBox();
            this.apDateBox = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.dataGridView4 = new System.Windows.Forms.DataGridView();
            this.label6 = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel5.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.panel6.SuspendLayout();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            this.panel2.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Location = new System.Drawing.Point(0, -2);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(803, 450);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.dataGridView1);
            this.tabPage1.Controls.Add(this.panel5);
            this.tabPage1.Controls.Add(this.label38);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage1.Size = new System.Drawing.Size(795, 421);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "TT Benh Nhan";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(0, 63);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.Size = new System.Drawing.Size(467, 356);
            this.dataGridView1.TabIndex = 33;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.SkyBlue;
            this.panel5.Controls.Add(this.pComboGenBox);
            this.panel5.Controls.Add(this.pAddressBox);
            this.panel5.Controls.Add(this.label1);
            this.panel5.Controls.Add(this.button11);
            this.panel5.Controls.Add(this.button15);
            this.panel5.Controls.Add(this.button12);
            this.panel5.Controls.Add(this.button13);
            this.panel5.Controls.Add(this.pPhoneBox);
            this.panel5.Controls.Add(this.label31);
            this.panel5.Controls.Add(this.label32);
            this.panel5.Controls.Add(this.pEmailBox);
            this.panel5.Controls.Add(this.pDOBBox);
            this.panel5.Controls.Add(this.pNameBox);
            this.panel5.Controls.Add(this.label34);
            this.panel5.Controls.Add(this.label35);
            this.panel5.Controls.Add(this.label36);
            this.panel5.Controls.Add(this.label37);
            this.panel5.Location = new System.Drawing.Point(469, -6);
            this.panel5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(324, 432);
            this.panel5.TabIndex = 32;
            // 
            // pComboGenBox
            // 
            this.pComboGenBox.FormattingEnabled = true;
            this.pComboGenBox.Location = new System.Drawing.Point(133, 98);
            this.pComboGenBox.Margin = new System.Windows.Forms.Padding(4);
            this.pComboGenBox.Name = "pComboGenBox";
            this.pComboGenBox.Size = new System.Drawing.Size(172, 24);
            this.pComboGenBox.TabIndex = 27;
            // 
            // pAddressBox
            // 
            this.pAddressBox.Location = new System.Drawing.Point(133, 139);
            this.pAddressBox.Margin = new System.Windows.Forms.Padding(4);
            this.pAddressBox.Name = "pAddressBox";
            this.pAddressBox.Size = new System.Drawing.Size(172, 22);
            this.pAddressBox.TabIndex = 26;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(29, 139);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(47, 16);
            this.label1.TabIndex = 25;
            this.label1.Text = "Địa chỉ";
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(229, 305);
            this.button11.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(83, 25);
            this.button11.TabIndex = 19;
            this.button11.Text = "Xóa";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // button15
            // 
            this.button15.Location = new System.Drawing.Point(94, 363);
            this.button15.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(152, 38);
            this.button15.TabIndex = 24;
            this.button15.Text = "Xem chi tiết";
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(133, 305);
            this.button12.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(83, 25);
            this.button12.TabIndex = 18;
            this.button12.Text = "Sửa";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(29, 305);
            this.button13.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(83, 25);
            this.button13.TabIndex = 17;
            this.button13.Text = "Thêm";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // pPhoneBox
            // 
            this.pPhoneBox.Location = new System.Drawing.Point(133, 265);
            this.pPhoneBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pPhoneBox.Name = "pPhoneBox";
            this.pPhoneBox.Size = new System.Drawing.Size(172, 22);
            this.pPhoneBox.TabIndex = 16;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.BackColor = System.Drawing.Color.SkyBlue;
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label31.Location = new System.Drawing.Point(64, 22);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(182, 25);
            this.label31.TabIndex = 2;
            this.label31.Text = "Bệnh nhân đã chọn";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(27, 268);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(85, 16);
            this.label32.TabIndex = 10;
            this.label32.Text = "Số điện thoại";
            // 
            // pEmailBox
            // 
            this.pEmailBox.Location = new System.Drawing.Point(133, 220);
            this.pEmailBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pEmailBox.Name = "pEmailBox";
            this.pEmailBox.Size = new System.Drawing.Size(172, 22);
            this.pEmailBox.TabIndex = 15;
            // 
            // pDOBBox
            // 
            this.pDOBBox.Location = new System.Drawing.Point(133, 177);
            this.pDOBBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pDOBBox.Name = "pDOBBox";
            this.pDOBBox.Size = new System.Drawing.Size(172, 22);
            this.pDOBBox.TabIndex = 12;
            // 
            // pNameBox
            // 
            this.pNameBox.Location = new System.Drawing.Point(133, 55);
            this.pNameBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pNameBox.Name = "pNameBox";
            this.pNameBox.Size = new System.Drawing.Size(172, 22);
            this.pNameBox.TabIndex = 14;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(27, 226);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(41, 16);
            this.label34.TabIndex = 7;
            this.label34.Text = "Email";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(27, 62);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(46, 16);
            this.label35.TabIndex = 4;
            this.label35.Text = "Họ tên";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(27, 102);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(54, 16);
            this.label36.TabIndex = 5;
            this.label36.Text = "Giới tính";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(27, 183);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(67, 16);
            this.label37.TabIndex = 6;
            this.label37.Text = "Ngày sinh";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(83, 27);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(275, 32);
            this.label38.TabIndex = 30;
            this.label38.Text = "Thông tin bệnh nhân";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.dataGridView2);
            this.tabPage2.Controls.Add(this.panel6);
            this.tabPage2.Controls.Add(this.label46);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage2.Size = new System.Drawing.Size(795, 421);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "TT Nha si";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(0, 63);
            this.dataGridView2.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowHeadersWidth = 51;
            this.dataGridView2.Size = new System.Drawing.Size(467, 356);
            this.dataGridView2.TabIndex = 42;
            this.dataGridView2.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellContentClick);
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.SkyBlue;
            this.panel6.Controls.Add(this.button3);
            this.panel6.Controls.Add(this.label40);
            this.panel6.Controls.Add(this.label39);
            this.panel6.Controls.Add(this.label41);
            this.panel6.Controls.Add(this.dID);
            this.panel6.Controls.Add(this.dGender);
            this.panel6.Controls.Add(this.dName);
            this.panel6.Controls.Add(this.label43);
            this.panel6.Controls.Add(this.label44);
            this.panel6.Location = new System.Drawing.Point(469, -6);
            this.panel6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(324, 432);
            this.panel6.TabIndex = 41;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(133, 185);
            this.button3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 25;
            this.button3.Text = "Xem";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(27, 191);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(84, 16);
            this.label40.TabIndex = 20;
            this.label40.Text = "Lịch làm việc";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.BackColor = System.Drawing.Color.SkyBlue;
            this.label39.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label39.Location = new System.Drawing.Point(105, 25);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(142, 25);
            this.label39.TabIndex = 2;
            this.label39.Text = "Nha sĩ đã chọn";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(27, 68);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(20, 16);
            this.label41.TabIndex = 3;
            this.label41.Text = "ID";
            // 
            // dID
            // 
            this.dID.Location = new System.Drawing.Point(133, 65);
            this.dID.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dID.Name = "dID";
            this.dID.Size = new System.Drawing.Size(172, 22);
            this.dID.TabIndex = 11;
            // 
            // dGender
            // 
            this.dGender.Location = new System.Drawing.Point(133, 140);
            this.dGender.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dGender.Name = "dGender";
            this.dGender.Size = new System.Drawing.Size(172, 22);
            this.dGender.TabIndex = 13;
            // 
            // dName
            // 
            this.dName.Location = new System.Drawing.Point(133, 100);
            this.dName.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dName.Name = "dName";
            this.dName.Size = new System.Drawing.Size(172, 22);
            this.dName.TabIndex = 14;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(27, 106);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(46, 16);
            this.label43.TabIndex = 4;
            this.label43.Text = "Họ tên";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(27, 146);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(54, 16);
            this.label44.TabIndex = 5;
            this.label44.Text = "Giới tính";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label46.Location = new System.Drawing.Point(125, 27);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(216, 32);
            this.label46.TabIndex = 39;
            this.label46.Text = "Thông tin nha sĩ";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.dataGridView3);
            this.tabPage3.Controls.Add(this.panel2);
            this.tabPage3.Controls.Add(this.label7);
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage3.Size = new System.Drawing.Size(795, 421);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "TT Nhan vien";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // dataGridView3
            // 
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Location = new System.Drawing.Point(0, 59);
            this.dataGridView3.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.RowHeadersWidth = 51;
            this.dataGridView3.Size = new System.Drawing.Size(467, 359);
            this.dataGridView3.TabIndex = 42;
            this.dataGridView3.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView3_CellContentClick);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.SkyBlue;
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.sIDBox);
            this.panel2.Controls.Add(this.sGenderBox);
            this.panel2.Controls.Add(this.sNameBox);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Location = new System.Drawing.Point(469, -6);
            this.panel2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(324, 432);
            this.panel2.TabIndex = 41;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.SkyBlue;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label2.Location = new System.Drawing.Point(105, 25);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(175, 25);
            this.label2.TabIndex = 2;
            this.label2.Text = "Nhân viên đã chọn";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(27, 68);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(20, 16);
            this.label3.TabIndex = 3;
            this.label3.Text = "ID";
            // 
            // sIDBox
            // 
            this.sIDBox.Location = new System.Drawing.Point(133, 65);
            this.sIDBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.sIDBox.Name = "sIDBox";
            this.sIDBox.Size = new System.Drawing.Size(172, 22);
            this.sIDBox.TabIndex = 11;
            // 
            // sGenderBox
            // 
            this.sGenderBox.Location = new System.Drawing.Point(133, 140);
            this.sGenderBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.sGenderBox.Name = "sGenderBox";
            this.sGenderBox.Size = new System.Drawing.Size(172, 22);
            this.sGenderBox.TabIndex = 13;
            // 
            // sNameBox
            // 
            this.sNameBox.Location = new System.Drawing.Point(133, 100);
            this.sNameBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.sNameBox.Name = "sNameBox";
            this.sNameBox.Size = new System.Drawing.Size(172, 22);
            this.sNameBox.TabIndex = 14;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(27, 106);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(46, 16);
            this.label4.TabIndex = 4;
            this.label4.Text = "Họ tên";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(27, 146);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(54, 16);
            this.label5.TabIndex = 5;
            this.label5.Text = "Giới tính";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(81, 27);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(264, 32);
            this.label7.TabIndex = 39;
            this.label7.Text = "Thông tin nhân viên";
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.currGenderBox);
            this.tabPage4.Controls.Add(this.panel3);
            this.tabPage4.Controls.Add(this.panel1);
            this.tabPage4.Controls.Add(this.button10);
            this.tabPage4.Controls.Add(this.button9);
            this.tabPage4.Controls.Add(this.currUserTypeBox);
            this.tabPage4.Controls.Add(this.currPasswordBox);
            this.tabPage4.Controls.Add(this.currNameBox);
            this.tabPage4.Controls.Add(this.currUsernameBox);
            this.tabPage4.Controls.Add(this.currIDBox);
            this.tabPage4.Controls.Add(this.label24);
            this.tabPage4.Controls.Add(this.label26);
            this.tabPage4.Controls.Add(this.label27);
            this.tabPage4.Controls.Add(this.label28);
            this.tabPage4.Controls.Add(this.label29);
            this.tabPage4.Controls.Add(this.label30);
            this.tabPage4.Controls.Add(this.label17);
            this.tabPage4.Location = new System.Drawing.Point(4, 25);
            this.tabPage4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage4.Size = new System.Drawing.Size(795, 421);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "TT Ca nhan";
            this.tabPage4.UseVisualStyleBackColor = true;
            this.tabPage4.Click += new System.EventHandler(this.tabPage4_Click);
            // 
            // currGenderBox
            // 
            this.currGenderBox.BackColor = System.Drawing.Color.SkyBlue;
            this.currGenderBox.FormattingEnabled = true;
            this.currGenderBox.Items.AddRange(new object[] {
            "Nam",
            "Nu",
            "Khac"});
            this.currGenderBox.Location = new System.Drawing.Point(351, 236);
            this.currGenderBox.Margin = new System.Windows.Forms.Padding(4);
            this.currGenderBox.Name = "currGenderBox";
            this.currGenderBox.Size = new System.Drawing.Size(224, 24);
            this.currGenderBox.TabIndex = 89;
            this.currGenderBox.SelectedIndexChanged += new System.EventHandler(this.comboBox2_SelectedIndexChanged);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.SkyBlue;
            this.panel3.Location = new System.Drawing.Point(672, 0);
            this.panel3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(123, 430);
            this.panel3.TabIndex = 88;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.SkyBlue;
            this.panel1.Location = new System.Drawing.Point(3, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(123, 430);
            this.panel1.TabIndex = 87;
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(451, 342);
            this.button10.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(107, 39);
            this.button10.TabIndex = 86;
            this.button10.Text = "Thoát";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(256, 342);
            this.button9.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(107, 39);
            this.button9.TabIndex = 85;
            this.button9.Text = "Cập nhật";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // currUserTypeBox
            // 
            this.currUserTypeBox.BackColor = System.Drawing.SystemColors.Window;
            this.currUserTypeBox.Location = new System.Drawing.Point(351, 284);
            this.currUserTypeBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.currUserTypeBox.Name = "currUserTypeBox";
            this.currUserTypeBox.Size = new System.Drawing.Size(224, 22);
            this.currUserTypeBox.TabIndex = 84;
            this.currUserTypeBox.TextChanged += new System.EventHandler(this.textBox20_TextChanged);
            // 
            // currPasswordBox
            // 
            this.currPasswordBox.BackColor = System.Drawing.Color.SkyBlue;
            this.currPasswordBox.Location = new System.Drawing.Point(351, 156);
            this.currPasswordBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.currPasswordBox.Name = "currPasswordBox";
            this.currPasswordBox.Size = new System.Drawing.Size(224, 22);
            this.currPasswordBox.TabIndex = 81;
            this.currPasswordBox.TextChanged += new System.EventHandler(this.textBox18_TextChanged);
            // 
            // currNameBox
            // 
            this.currNameBox.Location = new System.Drawing.Point(351, 191);
            this.currNameBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.currNameBox.Name = "currNameBox";
            this.currNameBox.Size = new System.Drawing.Size(224, 22);
            this.currNameBox.TabIndex = 80;
            this.currNameBox.TextChanged += new System.EventHandler(this.textBox14_TextChanged);
            // 
            // currUsernameBox
            // 
            this.currUsernameBox.Location = new System.Drawing.Point(351, 121);
            this.currUsernameBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.currUsernameBox.Name = "currUsernameBox";
            this.currUsernameBox.Size = new System.Drawing.Size(224, 22);
            this.currUsernameBox.TabIndex = 79;
            this.currUsernameBox.TextChanged += new System.EventHandler(this.textBox16_TextChanged);
            // 
            // currIDBox
            // 
            this.currIDBox.BackColor = System.Drawing.Color.SkyBlue;
            this.currIDBox.Location = new System.Drawing.Point(351, 81);
            this.currIDBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.currIDBox.Name = "currIDBox";
            this.currIDBox.Size = new System.Drawing.Size(224, 22);
            this.currIDBox.TabIndex = 78;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(220, 288);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(85, 18);
            this.label24.TabIndex = 77;
            this.label24.Text = "Phân quyền";
            this.label24.Click += new System.EventHandler(this.label24_Click);
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(220, 236);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(62, 18);
            this.label26.TabIndex = 75;
            this.label26.Text = "Giới tính";
            this.label26.Click += new System.EventHandler(this.label26_Click);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(220, 196);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(33, 18);
            this.label27.TabIndex = 74;
            this.label27.Text = "Tên";
            this.label27.Click += new System.EventHandler(this.label27_Click);
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(220, 158);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(69, 18);
            this.label28.TabIndex = 73;
            this.label28.Text = "Mật khẩu";
            this.label28.Click += new System.EventHandler(this.label28_Click);
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(220, 122);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(73, 18);
            this.label29.TabIndex = 72;
            this.label29.Text = "Tài khoản";
            this.label29.Click += new System.EventHandler(this.label29_Click);
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(224, 85);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(22, 18);
            this.label30.TabIndex = 71;
            this.label30.Text = "ID";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.SkyBlue;
            this.label17.Location = new System.Drawing.Point(251, 17);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(277, 38);
            this.label17.TabIndex = 70;
            this.label17.Text = "Thông tin cá nhân";
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.apStatusBox);
            this.tabPage5.Controls.Add(this.label13);
            this.tabPage5.Controls.Add(this.apPatientBox);
            this.tabPage5.Controls.Add(this.apDentistBox);
            this.tabPage5.Controls.Add(this.apRoomBox);
            this.tabPage5.Controls.Add(this.apDateBox);
            this.tabPage5.Controls.Add(this.label12);
            this.tabPage5.Controls.Add(this.label11);
            this.tabPage5.Controls.Add(this.label10);
            this.tabPage5.Controls.Add(this.label9);
            this.tabPage5.Controls.Add(this.label8);
            this.tabPage5.Controls.Add(this.panel4);
            this.tabPage5.Location = new System.Drawing.Point(4, 25);
            this.tabPage5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage5.Size = new System.Drawing.Size(795, 421);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "LichHen";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // apStatusBox
            // 
            this.apStatusBox.Location = new System.Drawing.Point(600, 242);
            this.apStatusBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.apStatusBox.Name = "apStatusBox";
            this.apStatusBox.Size = new System.Drawing.Size(163, 22);
            this.apStatusBox.TabIndex = 12;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(504, 209);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(70, 16);
            this.label13.TabIndex = 11;
            this.label13.Text = "Bệnh nhân";
            // 
            // apPatientBox
            // 
            this.apPatientBox.Location = new System.Drawing.Point(600, 203);
            this.apPatientBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.apPatientBox.Name = "apPatientBox";
            this.apPatientBox.Size = new System.Drawing.Size(163, 22);
            this.apPatientBox.TabIndex = 10;
            // 
            // apDentistBox
            // 
            this.apDentistBox.Location = new System.Drawing.Point(600, 165);
            this.apDentistBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.apDentistBox.Name = "apDentistBox";
            this.apDentistBox.Size = new System.Drawing.Size(163, 22);
            this.apDentistBox.TabIndex = 9;
            // 
            // apRoomBox
            // 
            this.apRoomBox.Location = new System.Drawing.Point(600, 127);
            this.apRoomBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.apRoomBox.Name = "apRoomBox";
            this.apRoomBox.Size = new System.Drawing.Size(163, 22);
            this.apRoomBox.TabIndex = 8;
            // 
            // apDateBox
            // 
            this.apDateBox.Location = new System.Drawing.Point(600, 84);
            this.apDateBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.apDateBox.Name = "apDateBox";
            this.apDateBox.Size = new System.Drawing.Size(163, 22);
            this.apDateBox.TabIndex = 7;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(504, 249);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(67, 16);
            this.label12.TabIndex = 6;
            this.label12.Text = "Trạng thái";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(504, 165);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(47, 16);
            this.label11.TabIndex = 5;
            this.label11.Text = "Nha sĩ";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(504, 127);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(46, 16);
            this.label10.TabIndex = 4;
            this.label10.Text = "Phòng";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(504, 90);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(65, 16);
            this.label9.TabIndex = 3;
            this.label9.Text = "Ngày hẹn";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(557, 41);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(166, 25);
            this.label8.TabIndex = 2;
            this.label8.Text = "Thông tin lịch hẹn";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.SkyBlue;
            this.panel4.Controls.Add(this.dataGridView4);
            this.panel4.Controls.Add(this.label6);
            this.panel4.Location = new System.Drawing.Point(-4, 0);
            this.panel4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(481, 425);
            this.panel4.TabIndex = 0;
            // 
            // dataGridView4
            // 
            this.dataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView4.Location = new System.Drawing.Point(4, 57);
            this.dataGridView4.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView4.Name = "dataGridView4";
            this.dataGridView4.RowHeadersWidth = 51;
            this.dataGridView4.Size = new System.Drawing.Size(477, 364);
            this.dataGridView4.TabIndex = 1;
            this.dataGridView4.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView4_CellContentClick);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(144, 14);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(161, 32);
            this.label6.TabIndex = 0;
            this.label6.Text = "Lịch đã hẹn";
            // 
            // Nhasi
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tabControl1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Nhasi";
            this.Text = "Nhasi";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.TextBox pPhoneBox;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TextBox pEmailBox;
        private System.Windows.Forms.TextBox pDOBBox;
        private System.Windows.Forms.TextBox pNameBox;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.TextBox dID;
        private System.Windows.Forms.TextBox dGender;
        private System.Windows.Forms.TextBox dName;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox sIDBox;
        private System.Windows.Forms.TextBox sGenderBox;
        private System.Windows.Forms.TextBox sNameBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.TextBox currUserTypeBox;
        private System.Windows.Forms.TextBox currPasswordBox;
        private System.Windows.Forms.TextBox currNameBox;
        private System.Windows.Forms.TextBox currUsernameBox;
        private System.Windows.Forms.TextBox currIDBox;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ComboBox pComboGenBox;
        private System.Windows.Forms.TextBox pAddressBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.ComboBox currGenderBox;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox apPatientBox;
        private System.Windows.Forms.TextBox apDentistBox;
        private System.Windows.Forms.TextBox apRoomBox;
        private System.Windows.Forms.TextBox apDateBox;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox apStatusBox;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.DataGridView dataGridView4;
    }
}