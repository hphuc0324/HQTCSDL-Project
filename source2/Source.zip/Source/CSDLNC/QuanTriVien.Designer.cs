﻿namespace CSDLNC
{
    partial class QuanTriVien
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(QuanTriVien));
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.currGenderBox = new System.Windows.Forms.ComboBox();
            this.button10 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.currUserTypeBox = new System.Windows.Forms.TextBox();
            this.currPasswordBox = new System.Windows.Forms.TextBox();
            this.currNameBox = new System.Windows.Forms.TextBox();
            this.currUsernameBox = new System.Windows.Forms.TextBox();
            this.currIDBox = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.dataGridView5 = new System.Windows.Forms.DataGridView();
            this.panel7 = new System.Windows.Forms.Panel();
            this.sGenderBox = new System.Windows.Forms.ComboBox();
            this.button5 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.label47 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.sIDBox = new System.Windows.Forms.TextBox();
            this.sNameBox = new System.Windows.Forms.TextBox();
            this.label49 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.dataGridView4 = new System.Windows.Forms.DataGridView();
            this.panel6 = new System.Windows.Forms.Panel();
            this.button3 = new System.Windows.Forms.Button();
            this.dID = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.dGender = new System.Windows.Forms.ComboBox();
            this.label40 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.label39 = new System.Windows.Forms.Label();
            this.dName = new System.Windows.Forms.TextBox();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.panel5 = new System.Windows.Forms.Panel();
            this.pAddressBox = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.pComboGenBox = new System.Windows.Forms.ComboBox();
            this.button11 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.pPhoneBox = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.pEmailBox = new System.Windows.Forms.TextBox();
            this.pDOBBox = new System.Windows.Forms.TextBox();
            this.pNameBox = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.panel2 = new System.Windows.Forms.Panel();
            this.button20 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.label16 = new System.Windows.Forms.Label();
            this.desBox = new System.Windows.Forms.TextBox();
            this.tonkhoBox = new System.Windows.Forms.TextBox();
            this.thuocPriceBox = new System.Windows.Forms.TextBox();
            this.nameThuocBox = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.panel1 = new System.Windows.Forms.Panel();
            this.comboUserTypeBox = new System.Windows.Forms.ComboBox();
            this.comboGenderBox = new System.Windows.Forms.ComboBox();
            this.passwordBox = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.button19 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.usernameBox = new System.Windows.Forms.TextBox();
            this.fullnameBox = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.button4 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.apStatusBox = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.apPatientBox = new System.Windows.Forms.TextBox();
            this.apDentistBox = new System.Windows.Forms.TextBox();
            this.apRoomBox = new System.Windows.Forms.TextBox();
            this.apDateBox = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.dataGridView6 = new System.Windows.Forms.DataGridView();
            this.label10 = new System.Windows.Forms.Label();
            this.tabPage4.SuspendLayout();
            this.tabPage7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).BeginInit();
            this.panel7.SuspendLayout();
            this.tabPage6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).BeginInit();
            this.panel6.SuspendLayout();
            this.tabPage5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            this.panel5.SuspendLayout();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.panel2.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.panel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView6)).BeginInit();
            this.SuspendLayout();
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.currGenderBox);
            this.tabPage4.Controls.Add(this.button10);
            this.tabPage4.Controls.Add(this.button9);
            this.tabPage4.Controls.Add(this.panel4);
            this.tabPage4.Controls.Add(this.panel3);
            this.tabPage4.Controls.Add(this.currUserTypeBox);
            this.tabPage4.Controls.Add(this.currPasswordBox);
            this.tabPage4.Controls.Add(this.currNameBox);
            this.tabPage4.Controls.Add(this.currUsernameBox);
            this.tabPage4.Controls.Add(this.currIDBox);
            this.tabPage4.Controls.Add(this.label24);
            this.tabPage4.Controls.Add(this.label26);
            this.tabPage4.Controls.Add(this.label27);
            this.tabPage4.Controls.Add(this.label28);
            this.tabPage4.Controls.Add(this.label29);
            this.tabPage4.Controls.Add(this.label30);
            this.tabPage4.Controls.Add(this.label17);
            this.tabPage4.Location = new System.Drawing.Point(4, 25);
            this.tabPage4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(803, 433);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "TT Ca Nhan";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // currGenderBox
            // 
            this.currGenderBox.AutoCompleteCustomSource.AddRange(new string[] {
            "Nam",
            "Nu",
            "Khac"});
            this.currGenderBox.BackColor = System.Drawing.Color.SkyBlue;
            this.currGenderBox.FormattingEnabled = true;
            this.currGenderBox.Location = new System.Drawing.Point(347, 229);
            this.currGenderBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.currGenderBox.Name = "currGenderBox";
            this.currGenderBox.Size = new System.Drawing.Size(224, 24);
            this.currGenderBox.TabIndex = 55;
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(447, 362);
            this.button10.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(107, 39);
            this.button10.TabIndex = 52;
            this.button10.Text = "Thoát";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(252, 362);
            this.button9.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(107, 39);
            this.button9.TabIndex = 51;
            this.button9.Text = "Cập nhật";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.SkyBlue;
            this.panel4.Location = new System.Drawing.Point(0, 0);
            this.panel4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(123, 430);
            this.panel4.TabIndex = 54;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.SkyBlue;
            this.panel3.Location = new System.Drawing.Point(680, 0);
            this.panel3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(123, 430);
            this.panel3.TabIndex = 53;
            // 
            // currUserTypeBox
            // 
            this.currUserTypeBox.BackColor = System.Drawing.SystemColors.Window;
            this.currUserTypeBox.Location = new System.Drawing.Point(347, 272);
            this.currUserTypeBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.currUserTypeBox.Name = "currUserTypeBox";
            this.currUserTypeBox.Size = new System.Drawing.Size(224, 22);
            this.currUserTypeBox.TabIndex = 50;
            // 
            // currPasswordBox
            // 
            this.currPasswordBox.BackColor = System.Drawing.Color.SkyBlue;
            this.currPasswordBox.Location = new System.Drawing.Point(347, 149);
            this.currPasswordBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.currPasswordBox.Name = "currPasswordBox";
            this.currPasswordBox.Size = new System.Drawing.Size(224, 22);
            this.currPasswordBox.TabIndex = 47;
            // 
            // currNameBox
            // 
            this.currNameBox.Location = new System.Drawing.Point(347, 185);
            this.currNameBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.currNameBox.Name = "currNameBox";
            this.currNameBox.Size = new System.Drawing.Size(224, 22);
            this.currNameBox.TabIndex = 43;
            // 
            // currUsernameBox
            // 
            this.currUsernameBox.Location = new System.Drawing.Point(347, 114);
            this.currUsernameBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.currUsernameBox.Name = "currUsernameBox";
            this.currUsernameBox.Size = new System.Drawing.Size(224, 22);
            this.currUsernameBox.TabIndex = 41;
            // 
            // currIDBox
            // 
            this.currIDBox.BackColor = System.Drawing.Color.SkyBlue;
            this.currIDBox.Location = new System.Drawing.Point(347, 80);
            this.currIDBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.currIDBox.Name = "currIDBox";
            this.currIDBox.Size = new System.Drawing.Size(224, 22);
            this.currIDBox.TabIndex = 40;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(215, 276);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(85, 18);
            this.label24.TabIndex = 39;
            this.label24.Text = "Phân quyền";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(215, 229);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(62, 18);
            this.label26.TabIndex = 37;
            this.label26.Text = "Giới tính";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(215, 188);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(33, 18);
            this.label27.TabIndex = 36;
            this.label27.Text = "Tên";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(215, 150);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(69, 18);
            this.label28.TabIndex = 35;
            this.label28.Text = "Mật khẩu";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(215, 114);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(73, 18);
            this.label29.TabIndex = 34;
            this.label29.Text = "Tài khoản";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(219, 84);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(22, 18);
            this.label30.TabIndex = 33;
            this.label30.Text = "ID";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.SkyBlue;
            this.label17.Location = new System.Drawing.Point(245, 16);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(277, 38);
            this.label17.TabIndex = 0;
            this.label17.Text = "Thông tin cá nhân";
            // 
            // tabPage7
            // 
            this.tabPage7.Controls.Add(this.dataGridView5);
            this.tabPage7.Controls.Add(this.panel7);
            this.tabPage7.Controls.Add(this.label52);
            this.tabPage7.Location = new System.Drawing.Point(4, 25);
            this.tabPage7.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage7.Size = new System.Drawing.Size(803, 433);
            this.tabPage7.TabIndex = 6;
            this.tabPage7.Text = "TT Nhan Vien";
            this.tabPage7.UseVisualStyleBackColor = true;
            this.tabPage7.Click += new System.EventHandler(this.tabPage7_Click);
            // 
            // dataGridView5
            // 
            this.dataGridView5.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView5.Location = new System.Drawing.Point(0, 69);
            this.dataGridView5.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dataGridView5.Name = "dataGridView5";
            this.dataGridView5.RowHeadersWidth = 51;
            this.dataGridView5.Size = new System.Drawing.Size(469, 354);
            this.dataGridView5.TabIndex = 39;
            this.dataGridView5.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView5_CellContentClick);
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.SkyBlue;
            this.panel7.Controls.Add(this.sGenderBox);
            this.panel7.Controls.Add(this.button5);
            this.panel7.Controls.Add(this.button14);
            this.panel7.Controls.Add(this.label47);
            this.panel7.Controls.Add(this.label48);
            this.panel7.Controls.Add(this.sIDBox);
            this.panel7.Controls.Add(this.sNameBox);
            this.panel7.Controls.Add(this.label49);
            this.panel7.Controls.Add(this.label50);
            this.panel7.Location = new System.Drawing.Point(473, 0);
            this.panel7.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(324, 432);
            this.panel7.TabIndex = 38;
            this.panel7.Paint += new System.Windows.Forms.PaintEventHandler(this.panel7_Paint);
            // 
            // sGenderBox
            // 
            this.sGenderBox.FormattingEnabled = true;
            this.sGenderBox.Items.AddRange(new object[] {
            "Nam",
            "Nu",
            "Khac"});
            this.sGenderBox.Location = new System.Drawing.Point(133, 143);
            this.sGenderBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.sGenderBox.Name = "sGenderBox";
            this.sGenderBox.Size = new System.Drawing.Size(173, 24);
            this.sGenderBox.TabIndex = 20;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(196, 391);
            this.button5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(83, 25);
            this.button5.TabIndex = 19;
            this.button5.Text = "Xóa";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(79, 391);
            this.button14.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(83, 25);
            this.button14.TabIndex = 18;
            this.button14.Text = "Sửa";
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.BackColor = System.Drawing.Color.SkyBlue;
            this.label47.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label47.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label47.Location = new System.Drawing.Point(105, 25);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(175, 25);
            this.label47.TabIndex = 2;
            this.label47.Text = "Nhân viên đã chọn";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(27, 68);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(20, 16);
            this.label48.TabIndex = 3;
            this.label48.Text = "ID";
            // 
            // sIDBox
            // 
            this.sIDBox.Location = new System.Drawing.Point(133, 65);
            this.sIDBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.sIDBox.Name = "sIDBox";
            this.sIDBox.Size = new System.Drawing.Size(172, 22);
            this.sIDBox.TabIndex = 11;
            // 
            // sNameBox
            // 
            this.sNameBox.Location = new System.Drawing.Point(133, 106);
            this.sNameBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.sNameBox.Name = "sNameBox";
            this.sNameBox.Size = new System.Drawing.Size(172, 22);
            this.sNameBox.TabIndex = 14;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(27, 106);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(46, 16);
            this.label49.TabIndex = 4;
            this.label49.Text = "Họ tên";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(27, 146);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(54, 16);
            this.label50.TabIndex = 5;
            this.label50.Text = "Giới tính";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label52.Location = new System.Drawing.Point(88, 33);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(264, 32);
            this.label52.TabIndex = 36;
            this.label52.Text = "Thông tin nhân viên";
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.dataGridView4);
            this.tabPage6.Controls.Add(this.panel6);
            this.tabPage6.Controls.Add(this.label46);
            this.tabPage6.Location = new System.Drawing.Point(4, 25);
            this.tabPage6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage6.Size = new System.Drawing.Size(803, 433);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "TT Nha si";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // dataGridView4
            // 
            this.dataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView4.Location = new System.Drawing.Point(4, 69);
            this.dataGridView4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dataGridView4.Name = "dataGridView4";
            this.dataGridView4.RowHeadersWidth = 51;
            this.dataGridView4.Size = new System.Drawing.Size(465, 354);
            this.dataGridView4.TabIndex = 36;
            this.dataGridView4.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView4_CellContentClick);
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.SkyBlue;
            this.panel6.Controls.Add(this.button3);
            this.panel6.Controls.Add(this.dID);
            this.panel6.Controls.Add(this.label9);
            this.panel6.Controls.Add(this.dGender);
            this.panel6.Controls.Add(this.label40);
            this.panel6.Controls.Add(this.button1);
            this.panel6.Controls.Add(this.button6);
            this.panel6.Controls.Add(this.label39);
            this.panel6.Controls.Add(this.dName);
            this.panel6.Controls.Add(this.label43);
            this.panel6.Controls.Add(this.label44);
            this.panel6.Location = new System.Drawing.Point(473, 0);
            this.panel6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(324, 432);
            this.panel6.TabIndex = 35;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(133, 219);
            this.button3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 24;
            this.button3.Text = "Xem";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // dID
            // 
            this.dID.Location = new System.Drawing.Point(133, 64);
            this.dID.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dID.Name = "dID";
            this.dID.Size = new System.Drawing.Size(172, 22);
            this.dID.TabIndex = 23;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(28, 68);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(20, 16);
            this.label9.TabIndex = 22;
            this.label9.Text = "ID";
            // 
            // dGender
            // 
            this.dGender.FormattingEnabled = true;
            this.dGender.Items.AddRange(new object[] {
            "Nam",
            "Nu",
            "Khac"});
            this.dGender.Location = new System.Drawing.Point(135, 142);
            this.dGender.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dGender.Name = "dGender";
            this.dGender.Size = new System.Drawing.Size(172, 24);
            this.dGender.TabIndex = 21;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(27, 222);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(84, 16);
            this.label40.TabIndex = 20;
            this.label40.Text = "Lịch làm việc";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(192, 391);
            this.button1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(83, 25);
            this.button1.TabIndex = 19;
            this.button1.Text = "Xóa";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(81, 391);
            this.button6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(83, 25);
            this.button6.TabIndex = 18;
            this.button6.Text = "Sửa";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.BackColor = System.Drawing.Color.SkyBlue;
            this.label39.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label39.Location = new System.Drawing.Point(105, 25);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(142, 25);
            this.label39.TabIndex = 2;
            this.label39.Text = "Nha sĩ đã chọn";
            // 
            // dName
            // 
            this.dName.Location = new System.Drawing.Point(135, 103);
            this.dName.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dName.Name = "dName";
            this.dName.Size = new System.Drawing.Size(172, 22);
            this.dName.TabIndex = 14;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(28, 107);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(46, 16);
            this.label43.TabIndex = 4;
            this.label43.Text = "Họ tên";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(28, 149);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(54, 16);
            this.label44.TabIndex = 5;
            this.label44.Text = "Giới tính";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label46.Location = new System.Drawing.Point(100, 33);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(216, 32);
            this.label46.TabIndex = 33;
            this.label46.Text = "Thông tin nha sĩ";
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.dataGridView3);
            this.tabPage5.Controls.Add(this.panel5);
            this.tabPage5.Controls.Add(this.label38);
            this.tabPage5.Location = new System.Drawing.Point(4, 25);
            this.tabPage5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(803, 433);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "TT Benh Nhan";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // dataGridView3
            // 
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Location = new System.Drawing.Point(4, 69);
            this.dataGridView3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.RowHeadersWidth = 51;
            this.dataGridView3.Size = new System.Drawing.Size(463, 356);
            this.dataGridView3.TabIndex = 26;
            this.dataGridView3.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView3_CellContentClick);
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.SkyBlue;
            this.panel5.Controls.Add(this.pAddressBox);
            this.panel5.Controls.Add(this.label18);
            this.panel5.Controls.Add(this.pComboGenBox);
            this.panel5.Controls.Add(this.button11);
            this.panel5.Controls.Add(this.button15);
            this.panel5.Controls.Add(this.button12);
            this.panel5.Controls.Add(this.button13);
            this.panel5.Controls.Add(this.pPhoneBox);
            this.panel5.Controls.Add(this.label31);
            this.panel5.Controls.Add(this.label32);
            this.panel5.Controls.Add(this.pEmailBox);
            this.panel5.Controls.Add(this.pDOBBox);
            this.panel5.Controls.Add(this.pNameBox);
            this.panel5.Controls.Add(this.label34);
            this.panel5.Controls.Add(this.label35);
            this.panel5.Controls.Add(this.label36);
            this.panel5.Controls.Add(this.label37);
            this.panel5.Location = new System.Drawing.Point(473, 0);
            this.panel5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(324, 432);
            this.panel5.TabIndex = 25;
            // 
            // pAddressBox
            // 
            this.pAddressBox.Location = new System.Drawing.Point(133, 174);
            this.pAddressBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pAddressBox.Name = "pAddressBox";
            this.pAddressBox.Size = new System.Drawing.Size(172, 22);
            this.pAddressBox.TabIndex = 27;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(27, 182);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(47, 16);
            this.label18.TabIndex = 26;
            this.label18.Text = "Địa chỉ";
            this.label18.Click += new System.EventHandler(this.label18_Click);
            // 
            // pComboGenBox
            // 
            this.pComboGenBox.FormattingEnabled = true;
            this.pComboGenBox.Items.AddRange(new object[] {
            "Nam",
            "Nu",
            "Khac"});
            this.pComboGenBox.Location = new System.Drawing.Point(133, 137);
            this.pComboGenBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pComboGenBox.Name = "pComboGenBox";
            this.pComboGenBox.Size = new System.Drawing.Size(172, 24);
            this.pComboGenBox.TabIndex = 25;
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(133, 337);
            this.button11.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(83, 36);
            this.button11.TabIndex = 19;
            this.button11.Text = "Xóa";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // button15
            // 
            this.button15.Location = new System.Drawing.Point(93, 378);
            this.button15.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(152, 38);
            this.button15.TabIndex = 24;
            this.button15.Text = "Xem chi tiết";
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(235, 337);
            this.button12.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(83, 36);
            this.button12.TabIndex = 18;
            this.button12.Text = "Sửa";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(27, 337);
            this.button13.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(83, 36);
            this.button13.TabIndex = 17;
            this.button13.Text = "Thêm";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // pPhoneBox
            // 
            this.pPhoneBox.Location = new System.Drawing.Point(133, 287);
            this.pPhoneBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pPhoneBox.Name = "pPhoneBox";
            this.pPhoneBox.Size = new System.Drawing.Size(172, 22);
            this.pPhoneBox.TabIndex = 16;
            this.pPhoneBox.TextChanged += new System.EventHandler(this.pPhoneBox_TextChanged);
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.BackColor = System.Drawing.Color.SkyBlue;
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label31.Location = new System.Drawing.Point(75, 33);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(182, 25);
            this.label31.TabIndex = 2;
            this.label31.Text = "Bệnh nhân đã chọn";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(27, 290);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(85, 16);
            this.label32.TabIndex = 10;
            this.label32.Text = "Số điện thoại";
            this.label32.Click += new System.EventHandler(this.label32_Click);
            // 
            // pEmailBox
            // 
            this.pEmailBox.Location = new System.Drawing.Point(133, 250);
            this.pEmailBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pEmailBox.Name = "pEmailBox";
            this.pEmailBox.Size = new System.Drawing.Size(172, 22);
            this.pEmailBox.TabIndex = 15;
            this.pEmailBox.TextChanged += new System.EventHandler(this.pEmailBox_TextChanged);
            // 
            // pDOBBox
            // 
            this.pDOBBox.Location = new System.Drawing.Point(133, 212);
            this.pDOBBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pDOBBox.Name = "pDOBBox";
            this.pDOBBox.Size = new System.Drawing.Size(172, 22);
            this.pDOBBox.TabIndex = 12;
            this.pDOBBox.TextChanged += new System.EventHandler(this.pDOBBox_TextChanged);
            // 
            // pNameBox
            // 
            this.pNameBox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.pNameBox.Location = new System.Drawing.Point(133, 100);
            this.pNameBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pNameBox.Name = "pNameBox";
            this.pNameBox.Size = new System.Drawing.Size(172, 22);
            this.pNameBox.TabIndex = 14;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(27, 258);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(41, 16);
            this.label34.TabIndex = 7;
            this.label34.Text = "Email";
            this.label34.Click += new System.EventHandler(this.label34_Click);
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(27, 106);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(46, 16);
            this.label35.TabIndex = 4;
            this.label35.Text = "Họ tên";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(27, 146);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(54, 16);
            this.label36.TabIndex = 5;
            this.label36.Text = "Giới tính";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(27, 215);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(67, 16);
            this.label37.TabIndex = 6;
            this.label37.Text = "Ngày sinh";
            this.label37.Click += new System.EventHandler(this.label37_Click);
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(87, 33);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(275, 32);
            this.label38.TabIndex = 22;
            this.label38.Text = "Thông tin bệnh nhân";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.dataGridView2);
            this.tabPage3.Controls.Add(this.panel2);
            this.tabPage3.Controls.Add(this.label23);
            this.tabPage3.Controls.Add(this.label15);
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(803, 433);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "QL Thuoc";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(4, 69);
            this.dataGridView2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowHeadersWidth = 51;
            this.dataGridView2.Size = new System.Drawing.Size(469, 357);
            this.dataGridView2.TabIndex = 22;
            this.dataGridView2.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellContentClick);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.SkyBlue;
            this.panel2.Controls.Add(this.button20);
            this.panel2.Controls.Add(this.button2);
            this.panel2.Controls.Add(this.button8);
            this.panel2.Controls.Add(this.label16);
            this.panel2.Controls.Add(this.desBox);
            this.panel2.Controls.Add(this.tonkhoBox);
            this.panel2.Controls.Add(this.thuocPriceBox);
            this.panel2.Controls.Add(this.nameThuocBox);
            this.panel2.Controls.Add(this.label19);
            this.panel2.Controls.Add(this.label20);
            this.panel2.Controls.Add(this.label21);
            this.panel2.Controls.Add(this.label22);
            this.panel2.Location = new System.Drawing.Point(477, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(324, 432);
            this.panel2.TabIndex = 21;
            // 
            // button20
            // 
            this.button20.Location = new System.Drawing.Point(133, 303);
            this.button20.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(71, 34);
            this.button20.TabIndex = 19;
            this.button20.Text = "Xóa";
            this.button20.UseVisualStyleBackColor = true;
            this.button20.Click += new System.EventHandler(this.button20_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(31, 303);
            this.button2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(71, 34);
            this.button2.TabIndex = 18;
            this.button2.Text = "Thêm";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(235, 303);
            this.button8.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(71, 34);
            this.button8.TabIndex = 17;
            this.button8.Text = "Sửa";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.SkyBlue;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label16.Location = new System.Drawing.Point(99, 80);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(143, 25);
            this.label16.TabIndex = 2;
            this.label16.Text = "Thuốc đã chọn";
            // 
            // desBox
            // 
            this.desBox.Location = new System.Drawing.Point(133, 251);
            this.desBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.desBox.Name = "desBox";
            this.desBox.Size = new System.Drawing.Size(172, 22);
            this.desBox.TabIndex = 15;
            // 
            // tonkhoBox
            // 
            this.tonkhoBox.Location = new System.Drawing.Point(133, 208);
            this.tonkhoBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tonkhoBox.Name = "tonkhoBox";
            this.tonkhoBox.Size = new System.Drawing.Size(172, 22);
            this.tonkhoBox.TabIndex = 12;
            // 
            // thuocPriceBox
            // 
            this.thuocPriceBox.Location = new System.Drawing.Point(133, 171);
            this.thuocPriceBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.thuocPriceBox.Name = "thuocPriceBox";
            this.thuocPriceBox.Size = new System.Drawing.Size(172, 22);
            this.thuocPriceBox.TabIndex = 13;
            // 
            // nameThuocBox
            // 
            this.nameThuocBox.Location = new System.Drawing.Point(133, 132);
            this.nameThuocBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.nameThuocBox.Name = "nameThuocBox";
            this.nameThuocBox.Size = new System.Drawing.Size(172, 22);
            this.nameThuocBox.TabIndex = 14;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(27, 257);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(40, 16);
            this.label19.TabIndex = 7;
            this.label19.Text = "Mô tả";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(27, 138);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(66, 16);
            this.label20.TabIndex = 4;
            this.label20.Text = "Tên thuốc";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(27, 177);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(28, 16);
            this.label21.TabIndex = 5;
            this.label21.Text = "Giá";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(27, 214);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(56, 16);
            this.label22.TabIndex = 6;
            this.label22.Text = "Tồn kho";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(127, 33);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(210, 32);
            this.label23.TabIndex = 18;
            this.label23.Text = "Thông tin thuốc";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.SkyBlue;
            this.label15.Location = new System.Drawing.Point(197, 18);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(0, 38);
            this.label15.TabIndex = 1;
            this.label15.Click += new System.EventHandler(this.label15_Click);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.dataGridView1);
            this.tabPage1.Controls.Add(this.panel1);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage1.Size = new System.Drawing.Size(803, 433);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "QLTaiKhoan";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(7, 68);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.Size = new System.Drawing.Size(471, 356);
            this.dataGridView1.TabIndex = 18;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.SkyBlue;
            this.panel1.Controls.Add(this.comboUserTypeBox);
            this.panel1.Controls.Add(this.comboGenderBox);
            this.panel1.Controls.Add(this.passwordBox);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.button19);
            this.panel1.Controls.Add(this.button18);
            this.panel1.Controls.Add(this.button17);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.comboBox1);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.usernameBox);
            this.panel1.Controls.Add(this.fullnameBox);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Location = new System.Drawing.Point(483, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(324, 432);
            this.panel1.TabIndex = 17;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // comboUserTypeBox
            // 
            this.comboUserTypeBox.FormattingEnabled = true;
            this.comboUserTypeBox.Items.AddRange(new object[] {
            "admin",
            "staff",
            "dentist"});
            this.comboUserTypeBox.Location = new System.Drawing.Point(135, 276);
            this.comboUserTypeBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.comboUserTypeBox.Name = "comboUserTypeBox";
            this.comboUserTypeBox.Size = new System.Drawing.Size(172, 24);
            this.comboUserTypeBox.TabIndex = 23;
            // 
            // comboGenderBox
            // 
            this.comboGenderBox.FormattingEnabled = true;
            this.comboGenderBox.Items.AddRange(new object[] {
            "Nam",
            "Nu",
            "Khac"});
            this.comboGenderBox.Location = new System.Drawing.Point(135, 235);
            this.comboGenderBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.comboGenderBox.Name = "comboGenderBox";
            this.comboGenderBox.Size = new System.Drawing.Size(172, 24);
            this.comboGenderBox.TabIndex = 22;
            // 
            // passwordBox
            // 
            this.passwordBox.Location = new System.Drawing.Point(135, 158);
            this.passwordBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.passwordBox.Name = "passwordBox";
            this.passwordBox.Size = new System.Drawing.Size(172, 22);
            this.passwordBox.TabIndex = 21;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(28, 161);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(61, 16);
            this.label6.TabIndex = 20;
            this.label6.Text = "Mật khẩu";
            // 
            // button19
            // 
            this.button19.Location = new System.Drawing.Point(229, 364);
            this.button19.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(69, 28);
            this.button19.TabIndex = 19;
            this.button19.Text = "Sửa";
            this.button19.UseVisualStyleBackColor = true;
            this.button19.Click += new System.EventHandler(this.button19_Click);
            // 
            // button18
            // 
            this.button18.Location = new System.Drawing.Point(135, 364);
            this.button18.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(69, 28);
            this.button18.TabIndex = 18;
            this.button18.Text = "Xóa";
            this.button18.UseVisualStyleBackColor = true;
            this.button18.Click += new System.EventHandler(this.button18_Click);
            // 
            // button17
            // 
            this.button17.Location = new System.Drawing.Point(32, 364);
            this.button17.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(69, 28);
            this.button17.TabIndex = 17;
            this.button17.Text = "Thêm";
            this.button17.UseVisualStyleBackColor = true;
            this.button17.Click += new System.EventHandler(this.button17_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.SkyBlue;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label2.Location = new System.Drawing.Point(79, 68);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(174, 25);
            this.label2.TabIndex = 2;
            this.label2.Text = "Tài khoản đã chọn";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(28, 321);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(67, 16);
            this.label8.TabIndex = 10;
            this.label8.Text = "Trạng thái";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Kích hoạt",
            "Khóa"});
            this.comboBox1.Location = new System.Drawing.Point(135, 314);
            this.comboBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(172, 24);
            this.comboBox1.TabIndex = 16;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(28, 121);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(88, 16);
            this.label3.TabIndex = 3;
            this.label3.Text = "Tên tài khoản";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // usernameBox
            // 
            this.usernameBox.Location = new System.Drawing.Point(135, 117);
            this.usernameBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.usernameBox.Name = "usernameBox";
            this.usernameBox.Size = new System.Drawing.Size(172, 22);
            this.usernameBox.TabIndex = 11;
            // 
            // fullnameBox
            // 
            this.fullnameBox.Location = new System.Drawing.Point(135, 193);
            this.fullnameBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.fullnameBox.Name = "fullnameBox";
            this.fullnameBox.Size = new System.Drawing.Size(172, 22);
            this.fullnameBox.TabIndex = 14;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(28, 279);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(78, 16);
            this.label7.TabIndex = 7;
            this.label7.Text = "Phân quyền";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(28, 198);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(46, 16);
            this.label4.TabIndex = 4;
            this.label4.Text = "Họ tên";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(28, 239);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(54, 16);
            this.label5.TabIndex = 5;
            this.label5.Text = "Giới tính";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(111, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(256, 32);
            this.label1.TabIndex = 0;
            this.label1.Text = "Thông tin tài khoản";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage6);
            this.tabControl1.Controls.Add(this.tabPage7);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(-3, -2);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(811, 462);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.button4);
            this.tabPage2.Controls.Add(this.button7);
            this.tabPage2.Controls.Add(this.button16);
            this.tabPage2.Controls.Add(this.apStatusBox);
            this.tabPage2.Controls.Add(this.label13);
            this.tabPage2.Controls.Add(this.apPatientBox);
            this.tabPage2.Controls.Add(this.apDentistBox);
            this.tabPage2.Controls.Add(this.apRoomBox);
            this.tabPage2.Controls.Add(this.apDateBox);
            this.tabPage2.Controls.Add(this.label12);
            this.tabPage2.Controls.Add(this.label11);
            this.tabPage2.Controls.Add(this.label14);
            this.tabPage2.Controls.Add(this.label25);
            this.tabPage2.Controls.Add(this.label33);
            this.tabPage2.Controls.Add(this.panel8);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tabPage2.Size = new System.Drawing.Size(803, 433);
            this.tabPage2.TabIndex = 7;
            this.tabPage2.Text = "LichHen";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(707, 309);
            this.button4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 30;
            this.button4.Text = "Xóa";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(605, 309);
            this.button7.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(75, 23);
            this.button7.TabIndex = 29;
            this.button7.Text = "Sửa";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click_1);
            // 
            // button16
            // 
            this.button16.Location = new System.Drawing.Point(503, 309);
            this.button16.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(75, 23);
            this.button16.TabIndex = 28;
            this.button16.Text = "Thêm";
            this.button16.UseVisualStyleBackColor = true;
            this.button16.Click += new System.EventHandler(this.button16_Click);
            // 
            // apStatusBox
            // 
            this.apStatusBox.Location = new System.Drawing.Point(604, 245);
            this.apStatusBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.apStatusBox.Name = "apStatusBox";
            this.apStatusBox.Size = new System.Drawing.Size(163, 22);
            this.apStatusBox.TabIndex = 24;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(508, 212);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(70, 16);
            this.label13.TabIndex = 23;
            this.label13.Text = "Bệnh nhân";
            // 
            // apPatientBox
            // 
            this.apPatientBox.Location = new System.Drawing.Point(604, 206);
            this.apPatientBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.apPatientBox.Name = "apPatientBox";
            this.apPatientBox.Size = new System.Drawing.Size(163, 22);
            this.apPatientBox.TabIndex = 22;
            // 
            // apDentistBox
            // 
            this.apDentistBox.Location = new System.Drawing.Point(604, 167);
            this.apDentistBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.apDentistBox.Name = "apDentistBox";
            this.apDentistBox.Size = new System.Drawing.Size(163, 22);
            this.apDentistBox.TabIndex = 21;
            // 
            // apRoomBox
            // 
            this.apRoomBox.Location = new System.Drawing.Point(604, 130);
            this.apRoomBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.apRoomBox.Name = "apRoomBox";
            this.apRoomBox.Size = new System.Drawing.Size(163, 22);
            this.apRoomBox.TabIndex = 20;
            // 
            // apDateBox
            // 
            this.apDateBox.Location = new System.Drawing.Point(604, 87);
            this.apDateBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.apDateBox.Name = "apDateBox";
            this.apDateBox.Size = new System.Drawing.Size(163, 22);
            this.apDateBox.TabIndex = 19;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(508, 251);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(67, 16);
            this.label12.TabIndex = 18;
            this.label12.Text = "Trạng thái";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(508, 167);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(47, 16);
            this.label11.TabIndex = 17;
            this.label11.Text = "Nha sĩ";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(508, 130);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(46, 16);
            this.label14.TabIndex = 16;
            this.label14.Text = "Phòng";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(508, 94);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(65, 16);
            this.label25.TabIndex = 15;
            this.label25.Text = "Ngày hẹn";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(563, 44);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(166, 25);
            this.label33.TabIndex = 14;
            this.label33.Text = "Thông tin lịch hẹn";
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.SkyBlue;
            this.panel8.Controls.Add(this.dataGridView6);
            this.panel8.Controls.Add(this.label10);
            this.panel8.Location = new System.Drawing.Point(0, 2);
            this.panel8.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(481, 425);
            this.panel8.TabIndex = 13;
            // 
            // dataGridView6
            // 
            this.dataGridView6.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView6.Location = new System.Drawing.Point(0, 57);
            this.dataGridView6.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dataGridView6.Name = "dataGridView6";
            this.dataGridView6.RowHeadersWidth = 51;
            this.dataGridView6.Size = new System.Drawing.Size(477, 364);
            this.dataGridView6.TabIndex = 1;
            this.dataGridView6.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView6_CellContentClick);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(144, 14);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(161, 32);
            this.label10.TabIndex = 0;
            this.label10.Text = "Lịch đã hẹn";
            // 
            // QuanTriVien
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tabControl1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "QuanTriVien";
            this.Text = "QuanTriVien";
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.tabPage7.ResumeLayout(false);
            this.tabPage7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).EndInit();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.tabPage6.ResumeLayout(false);
            this.tabPage6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).EndInit();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView6)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox currUserTypeBox;
        private System.Windows.Forms.TextBox currPasswordBox;
        private System.Windows.Forms.TextBox currNameBox;
        private System.Windows.Forms.TextBox currUsernameBox;
        private System.Windows.Forms.TextBox currIDBox;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.TextBox sIDBox;
        private System.Windows.Forms.TextBox sNameBox;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.TextBox dName;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.TextBox pAddressBox;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.ComboBox pComboGenBox;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.TextBox pPhoneBox;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TextBox pEmailBox;
        private System.Windows.Forms.TextBox pDOBBox;
        private System.Windows.Forms.TextBox pNameBox;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox desBox;
        private System.Windows.Forms.TextBox tonkhoBox;
        private System.Windows.Forms.TextBox thuocPriceBox;
        private System.Windows.Forms.TextBox nameThuocBox;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ComboBox comboUserTypeBox;
        private System.Windows.Forms.ComboBox comboGenderBox;
        private System.Windows.Forms.TextBox passwordBox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox usernameBox;
        private System.Windows.Forms.TextBox fullnameBox;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.DataGridView dataGridView4;
        private System.Windows.Forms.ComboBox dGender;
        private System.Windows.Forms.DataGridView dataGridView5;
        private System.Windows.Forms.TextBox dID;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox sGenderBox;
        private System.Windows.Forms.ComboBox currGenderBox;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TextBox apStatusBox;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox apPatientBox;
        private System.Windows.Forms.TextBox apDentistBox;
        private System.Windows.Forms.TextBox apRoomBox;
        private System.Windows.Forms.TextBox apDateBox;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.DataGridView dataGridView6;
    }
}